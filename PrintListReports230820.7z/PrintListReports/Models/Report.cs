﻿using System;

namespace PrintListReports.Models
{
    public class Report
    {
        public int ReportID { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
    }
}
